/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pe.edu.pucp.prog03.webhooke.programacioncursos.dao;
import pe.edu.pucp.prog03.webhooke.programacioncursos.model.Sesion;
/**
 *
 * @author ASUS
 */
public interface SesionDAO extends ICRUD<Sesion>{
    
}
