package pe.edu.pucp.prog03.webhooke.modalidades.dao;
import pe.edu.pucp.prog03.webhooke.modalidades.model.TipoSesion;
 
public interface TipoSesionDAO extends ICRUD<TipoSesion>{

}
