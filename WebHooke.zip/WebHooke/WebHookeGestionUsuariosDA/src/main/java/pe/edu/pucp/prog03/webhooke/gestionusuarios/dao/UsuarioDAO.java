/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package pe.edu.pucp.prog03.webhooke.gestionusuarios.dao;
import pe.edu.pucp.prog03.webhooke.gestionusuarios.model.Usuario;
/**
 *
 * @author ASUS
 */
public interface UsuarioDAO extends ICRUD<Usuario>{
    
}
